---
name: New Feature Proposal
about: Propose a new feature
labels: enhancement
---

## Description

What are you proposing? How should it be implemented?

## Rationale

Why should this feature be implemented?
