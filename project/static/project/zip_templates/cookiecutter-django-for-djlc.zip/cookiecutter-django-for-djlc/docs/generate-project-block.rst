Generate a new cookiecutter-django project: ::

    $ cookiecutter gh:cookiecutter/cookiecutter-django

For more information refer to
:ref:`Project Generation Options <template-options>`.

